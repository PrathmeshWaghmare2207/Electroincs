package com.entity;

public class contactus {

	private int id;
	private String Name;
	private String Email_Id;
	private int Contact_No;
	private String Message;
	
	
	public contactus() {
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getEmail_Id() {
		return Email_Id;
	}


	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}


	public int getContact_No() {
		return Contact_No;
	}


	public void setContact_No(int contact_No) {
		Contact_No = contact_No;
	}


	public String getMessage() {
		return Message;
	}


	public void setMessage(String message) {
		Message = message;
	}
	
	
	
	
}
